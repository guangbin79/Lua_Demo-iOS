
-- Dummy module to store variables that need to be shared between other WSAPI modules

local _M = {}

return _M